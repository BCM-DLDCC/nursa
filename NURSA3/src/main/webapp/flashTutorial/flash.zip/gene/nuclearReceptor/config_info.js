// This MUST be equal to totalSlides in config_info.txt!
var totalSlides = 16;